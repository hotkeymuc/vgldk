#ifndef __FS_SD_H
#define __FS_SD_H

// SD Card Setup
#include <SPI.h>
#include <SD.h>

//#define FS_SD_DEBUG_ERRORS

#include "fs.h"

#ifndef FS_SD_PIN_CS
  #define FS_SD_PIN_CS 4
#endif
#define FS_SD_MAX_PATH 32

// Forwards
void fs_sd_mount(const char *options);
file_DIR *fs_sd_opendir(const char *path);
int fs_sd_closedir(file_DIR * dir);
dirent *fs_sd_readdir(file_DIR *dir);
file_FILE *fs_sd_fopen(const char *path, const char *openMode);
int fs_sd_fclose(file_FILE *f);
byte fs_sd_feof(file_FILE *f);
int fs_sd_fgetc(file_FILE *f);
size_t fs_sd_fread(void *ptr, size_t size, size_t nmemb, file_FILE *f);
size_t fs_sd_fwrite(void *ptr, size_t size, size_t nmemb, file_FILE *f);


// Publish a FS struct
const FS fs_sd = {	// Keep in sync with fs.h:FS!
	fs_sd_mount,
	
	fs_sd_opendir,
	fs_sd_closedir,
	fs_sd_readdir,
	
	fs_sd_fopen,
	fs_sd_fclose,
	fs_sd_feof,
	//fs_sd_fgetc,
	fs_sd_fread,
	fs_sd_fwrite
};


// Implementation
file_DIR fs_sd_tmpDir;
dirent fs_sd_tmpDirent;
File fs_sd_tmpDirHandle;	// for openDir()

file_FILE fs_sd_tmpFile;
File fs_sd_tmpFileHandle;	// for fopen()
char fs_sd_tmpName[FS_SD_MAX_PATH];

void fs_sd_select() {
  #ifdef ETH_PIN_CS
    // Disable W5100 on the Ethernet shield while SD is in use
    //pinMode(FS_ETH_PIN_CS, OUTPUT); // Do not set the pinMode!
    digitalWrite(ETH_PIN_CS, HIGH);
  #endif
  
  //pinMode(FS_SD_PIN_CS, OUTPUT);
  digitalWrite(FS_SD_PIN_CS, LOW);
}

void fs_sd_mount(const char *options) {
	//byte v;
	
	(void)options;

  fs_sd_select();

  #ifdef FS_SD_DEBUG
    put(F("#SD mount..."));
  #endif
  //if (!sd.begin(FS_SD_PIN_CS, SD_SCK_MHZ(50))) {  // SdFat
	if (!SD.begin(FS_SD_PIN_CS)) {  // SD
    #ifdef FS_SD_DEBUG_ERRORS
      put(F("#SD init failed"));
    #endif
	} else {
  #ifdef FS_SD_DEBUG
    put(F("#SD ready..."));
  #endif
	}
}

file_DIR *fs_sd_opendir(const char *path) {
	file_DIR * dir;  // file_DIR to be returned
	const char *pp;
	File h;
	
	// Skip initial slash
	pp = path;
	//if (*pp == FILE_PATH_DELIMITER) pp++;

  fs_sd_select();
  
	if ((*pp != 0) && (!SD.exists((char *)pp))) {
    #ifdef FS_SD_DEBUG_ERRORS
      put(F("#SD dir not exist!"));
    #endif
		return NULL;
	}
 
  #ifdef FS_SD_DEBUG
    put_(F("#SD opendir \"")); put_(pp); put_(F("\"..."));
  #endif
  
	h = SD.open((char *)pp);
	if (h == 0) {
    #ifdef FS_SD_DEBUG_ERRORS
      put(F("#SD dir open failed!"));
    #endif
		return NULL;
	}
  #ifdef FS_SD_DEBUG
    put(F("OK"));
  #endif
	
	// Store handle
	fs_sd_tmpDirHandle = h;	//@FIXME: Using the ONE temp. dirHandle...
	
	dir = &fs_sd_tmpDir;	//@FIXME: Using the ONE temp. dir...
	dir->fs = &fs_sd;
	dir->count = 0;	//@TODO: Can be determined from SD
	dir->userData = (void *)&fs_sd_tmpDirHandle;
	
	dir->currentPos = 0;	// Rewind
	return dir;
	
}

int fs_sd_closedir(file_DIR * dir) {
	File *dirHandle;
  
	//dirHandle = fs_sd_tmpDirHandle;
	dirHandle = (File *)dir->userData;

  fs_sd_select();
  
	dirHandle->close();
	
	dir->count = 0;
	return 0;
}

dirent *fs_sd_readdir(file_DIR *dir) {
	dirent *de;
	File *dirHandle;
	File fileHandle;
	
	//dirHandle = fs_sd_tmpDirHandle;
	dirHandle = (File *)dir->userData;

  fs_sd_select();
  
	fileHandle = dirHandle->openNextFile(); // SD
  //file.openNext(dirHandle, O_RDONLY); // SdFat
 
 
	//if (dir->currentPos >= dir->count) {
	if (!fileHandle) {
		// Done.
		return NULL;
	}
	
	//fileHandle.name()
	//fileHandle.isDirectory()
	//fileHandle.size()
	//fileHandle.available()
	
	// Create a dirent
	de = &fs_sd_tmpDirent;		//@FIXME: Using the ONE temp. dir.ent..
	de->pos = dir->currentPos;
	de->name = &fs_sd_tmpName[0];
	strcpy(&fs_sd_tmpName[0], fileHandle.name());

  fileHandle.close(); // Important
  
	dir->currentPos++;
	
	return de;
}

file_FILE *fs_sd_fopen(const char *path, const char *openMode) {
	file_FILE *f;	// file_FILE to be returned
	const char *pp;
	File h;
	
	pp = path;
	if (*pp == FILE_PATH_DELIMITER) pp++;	// Skip initial slash

  fs_sd_select();
  
	if (!SD.exists((char *)pp)) {
    #ifdef FS_SD_DEBUG_ERRORS
      put(F("#SD file not exist!"));
    #endif
		return NULL;
	}

 //@TODO: openMode: (mode == PB_FILE_WRITE) ? FILE_WRITE : FILE_READ
	h = SD.open((char *)pp, FILE_READ);
	if (h == 0) {
    #ifdef FS_SD_DEBUG_ERRORS
      put(F("#SD file open failed!"));
    #endif
		return NULL;
	}
	
	// Store handle
	fs_sd_tmpFileHandle = h;
	
	f = &fs_sd_tmpFile;		//@FIXME: Using the ONE temp. file...
  f->name = &fs_sd_tmpName[0];
  strcpy(&fs_sd_tmpName[0], h.name());

	f->fs = &fs_sd;
	f->userData = (void *)&fs_sd_tmpFileHandle;
	f->size = h.size();
	
	f->mode = openMode;
	f->currentPos = 0;
	
	return f;
}

int fs_sd_fclose(file_FILE *f) {
	File *h;
	
	h = (File *)f->userData;

  fs_sd_select();
	h->close();
	
	return 0;
}

byte fs_sd_feof(file_FILE *f) {
	(void)f;
	return 1; //@TODO: Implement
}

int fs_sd_fgetc(file_FILE *f) {
	(void)f;
	return -1;	// EOF
}

size_t fs_sd_fread(void *ptr, size_t size, size_t nmemb, file_FILE *f) {
	File *h;
	size_t l;
	
	size *= nmemb;
	
	h = (File *)f->userData;

  fs_sd_select();
  
	l = h->read(ptr, size);
	
	return l;
}

size_t fs_sd_fwrite(void *ptr, size_t size, size_t nmemb, file_FILE *f) {
	(void)ptr;
	(void)size;
	(void)nmemb;
	(void)f;
	
	//File h;
	//h = (File)f->userData;
  fs_sd_select();
	
	return 0;
}

#endif
