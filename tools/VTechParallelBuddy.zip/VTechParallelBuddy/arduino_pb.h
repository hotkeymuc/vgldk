#ifndef __ARDUINO_PB_H
#define __ARDUINO_PB_H

// PB Protocol Arduino glue

#ifndef PB_SERIAL_BAUD
  #define PB_SERIAL_BAUD 9600 // 9600 for classic SoftSerial, 19200 for experimental cSerial
#endif
//#define pb_serial Serial1

// Include the ACTUAL parabuddy definition from the VGLDK
#define PB_USE_ARDUINO
#include "parabuddy.h"


bool pb_bootLoaderMode; // State (1=RAW passthrough "bootloader mode" or 0=full PB mode)
word pb_o;  // Offset in current frame
byte pb_len = 0;
byte pb_frame[PB_MAX_FRAME_SIZE]; // Current frame being received


//#define PB_DEBUG_FRAMES
//#define PB_DEBUG_SENDING
//#define PB_DEBUG_PROTOCOL_ERRORS
//#define PB_AUTOSTART_BOOTLOADER
#define PB_BOOTLOADER_TIMEOUT 2000  // Or un-define it for no bootloader timeout
unsigned long pb_lastBootLoaderMillis;  // Last host bytes in bootloader mode

#define PB_PROTO_TIMEOUT 1000 // If a frame does not finish within x milliseconds: Reset PB protocol state
unsigned long pb_lastProto; // Last start of packet



// binary protocol helpers
byte pb_getByte(byte *b) {
  return *b;
}
word pb_getWord(byte *b) {
  // MSB first
  //return (((word)(*b++)) << 8) + *b;

  // Z80 is LSB first
  return (word)*b++ + (((word)(*b++)) << 8);
}
void pb_putWord(byte *b, word v) {
  // MSB first
  //*b++ = (v >> 8);
  //*b   = (v & 0xff);
  
  *b++ = (v & 0xff);
  *b   = (v >> 8);
}


// Return helpers
void pb_returnByte(byte v) {
  pb_sendByte(PB_COMMAND_RETURN_BYTE, v);
}
void pb_returnWord(word v) {
  pb_sendWord(PB_COMMAND_RETURN_WORD, v);
}
void pb_returnAsciiz(byte *s) {
  int l;
  byte *pc;
  l = 0;
  pc = s;
  while (*pc != 00) {
    pc++;
    l++;
  }
  pb_sendFrame(PB_COMMAND_RETURN_ASCIIZ, s, l);
}
void pb_returnData(byte *d, byte l) {
  pb_sendFrame(PB_COMMAND_RETURN_DATA, d, l);
}

// More lifecycle glue
void pb_flushInput() {
  // Read everything there is
  while (pb_serial.available()) {
    pb_serial.read();
  }
  pb_o = 0;
}


void pb_handleCommand(byte cmd, byte *f, word l); // Forward declaration

void pb_handleFrame(byte *frame, word fLen) {
  // Handle an incoming frame, check for validity, call pb_handleCommand()
  word l;
  word c;
  byte *f;

  /*
  // Special case: Boot loader can be disabled by VGL
  if (pb_bootLoaderMode) {
    if (fLen != 2) return;  // Nothing to handle in boot loader mode except that single message
    if (*(f+1) == PB_COMMAND_END_BOOTLOADER) {
      pb_bootLoaderMode = false;
      hostSerial.print("#EBL\n");  // Inform PC that boot loader ended
    }

    // In bootloader mode: Do not handle commands
    return;
  }
  */
  
  
  // Check if length is plausible
  if (fLen == 0) {
    // Too short
    return;
  }
  
  f = frame;

  // Get protocol length
  //l = pb_getWord(f); f+=2;
  l = *f++;
  
  // Ignore "empty" frames
  if ((fLen == 1) && (l == 0)) {
    // Sometimes a stray "0x00" will pop up. Just ignore it.
    /*
    #ifdef PB_DEBUG_PROTOCOL_ERRORS
      hostSerial.println(F("#Empty"));
    #endif
    */
    return;
  }

  // Dump stats
  #ifdef PB_DEBUG_FRAMES
    // Debug
    hostSerial.print("#Frame fLen=");
    hostSerial.print(fLen);
    hostSerial.print(":");
    for (int i = 0; i < fLen; i++) {
      hostSerial.print(" ");
      hostSerial.print(*(frame+i), HEX);
    }
    hostSerial.println();
  #endif

  // Check validity
  if (l+1 != fLen) {
    // Length mismatch (protocol VS received frame)
    #ifdef PB_DEBUG_PROTOCOL_ERRORS
      hostSerial.print(F("#Len! l="));
      hostSerial.print(l);
      hostSerial.print(F(", fLen="));
      hostSerial.println(fLen);
    #endif
    
    //pb_sendNACK(PB_ERROR_LENGTH);
    return;
  }

  // Get the command
  c = *f++;
  l--;
  
  //c = pb_getWord(f); f += 2;
  #ifdef PB_DEBUG_FRAMES
    hostSerial.print("#Cmd 0x"); hostSerial.println(c, HEX);
  #endif
  
  pb_handleCommand(c, f, l);  
}

void pb_handleIncomingByte(byte b) {
  // Handle an incoming byte, handle timeout, call pb_handleFrame() if frame fully received

  if (pb_o == 0) {
    // First byte is length

    if (b == 0) return; // Ignore zero length frames
    
    pb_len = b;
    pb_lastProto = millis();
    //hostSerial.print("#Start frame len="); hostSerial.println(pb_len);
  
  } else
  if (pb_o >= PB_MAX_FRAME_SIZE) {
    // Too big
    pb_o = PB_MAX_FRAME_SIZE-1;
    #ifdef PB_DEBUG_PROTOCOL_ERRORS
      hostSerial.println(F("#Overflow"));
    #endif
    //return;  // Prevent overflow
    //pb_sendNACK(PB_ERROR_LENGTH);
  }
  
  // Store byte
  pb_frame[pb_o] = b;
  pb_o++;

  //hostSerial.print("#pb_o="); hostSerial.println(pb_o);
  
  if (pb_o > pb_len) {
    // End of frame
    //pb_frame[pb_o] = 0x00;  // Zero termination
    pb_handleFrame(&pb_frame[0], pb_o);
    pb_o = 0;
    pb_len = 0;
  }
}


void pb_loop_pb() {
  int c;
  int d;
  
  // PB mode: Just pass everything through

  // while (pb_serial.available()) {
  if (pb_serial.available()) {
    c = pb_serial.read();  // Could be -1 if nothing read!
    
    // Debug
    #ifdef PB_DEBUG_RECEIVING
      hostSerial.print("# PB:");
      hostSerial.println(c, HEX);
    #endif
    
    // In normal mode: Handle pb protocol
    pb_handleIncomingByte(c);
  }
  
  // Check for protocol timeout
  if (pb_o > 0) {
    d = millis() - pb_lastProto;
    
    if (d > PB_PROTO_TIMEOUT) {
      // Reset protocol state
      #ifdef PB_DEBUG_PROTOCOL_ERRORS
      hostSerial.println(F("#RST proto"));
      #endif
      pb_o = 0;
    }
  }
  
}

void pb_loop_bootloader() {
  int c;
  unsigned long t;
  int d;
  
  t = millis();
  
  //while (pb_serial.available()) {
  if (pb_serial.available()) {
    
    // Read byte from VGL in a loop
    c = pb_serial.read();  // Could be -1 if nothing read!
    
    // In bootloader mode: Pass all VGL bytes to PC
    hostSerial.write(c);
  }
  
  //while (hostSerial.available()) {
  if (hostSerial.available()) {
    // Read byte from PC
    c = hostSerial.read();  // Could be -1 if nothing read!
    //if (c == -1) break;
    
    // In bootloader mode: Pass all host bytes to VGL
    pb_serial.write(c);
    //pb_serial.flush();  // Wait until all bytes are sent to the VGL
    
    pb_lastBootLoaderMillis = t;  // Update timeout
  }

  // Turn off bootloader mode after some timeout
  #ifdef PB_BOOTLOADER_TIMEOUT
  d = t - pb_lastBootLoaderMillis;
  if (d > PB_BOOTLOADER_TIMEOUT) {
    // Debug
    hostSerial.println(F("#EBL-TO"));
    
    pb_bootLoaderMode = false;
    pb_o = 0;
    pb_lastProto = t;
  }
  #endif
}


void pb_setup() {
  /*
  // Init hardware serial
  hostSerial.begin(HOST_SERIAL_BAUD);
  while (!hostSerial) {
    ; // wait for serial port to connect. Needed for native USB port only
  }
  */
  
  // Init serial to VGL
  pb_serial.begin(PB_SERIAL_BAUD);
  //pb_serial.listen();  // if using more than one SoftwareSerial
  
  pb_flushInput();

  #ifdef PB_AUTOSTART_BOOTLOADER
    pb_bootLoaderMode = true;
    if (pb_bootLoaderMode) {
      hostSerial.print(F("#BLM\n"));  // Inform PC that we are in bootloader mode
      pb_lastBootLoaderMillis = millis();
    }
  #else
    pb_bootLoaderMode = false;
  #endif
  pb_o = 0;
}


void pb_loop() {

  if (pb_bootLoaderMode) {
    pb_loop_bootloader();

  } else {
    pb_loop_pb();
  }
}

#endif //__ARDUINO_PB_H
