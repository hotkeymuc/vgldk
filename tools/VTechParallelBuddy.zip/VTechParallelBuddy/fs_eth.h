#ifndef __FS_ETH_H
#define __FS_ETH_H


//@TODO: Implement telnet/http/ftp/ping

#include <SPI.h>
#include <Ethernet.h>

#ifndef FS_ETH_PIN_CS
  #define FS_ETH_PIN_CS 10  // Ethernet shield: Pin 10 = W5100 SlaveSelect
#endif
#define FS_ETH_MAX_FQDN 32
#define FS_ETH_MAX_PATH 32

byte mac[] = { 0xA7, 0xD0, 0x14, 0x0B, 0x0D, 0xD4 };  // ARD0INO BUDDY

IPAddress ip(192, 168, 4, 177);
IPAddress ip_dns(192, 168, 4, 104);
IPAddress ip_gateway(192, 168, 4, 104);
IPAddress ip_subnet(255, 255, 255, 0);


// Enter the IP address of the server you're connecting to:
//IPAddress ip_server(192, 168, 4, 120);
//char server_fqdn[] = "www.google.com";    // name address for Google (using DNS)
EthernetClient fs_eth_client; //@TODO: Multiple?
//EthernetServer fs_eth_server; //@TODO: Multiple?

void fs_eth_select() {
  #ifdef SD_PIN_CS
    // Disable SD on the Ethernet shield while SD is in use
    //pinMode(FS_SD_PIN_CS, OUTPUT);
    //digitalWrite(SD_PIN_CS, HIGH);
  #endif
  
  //pinMode(FS_ETH_PIN_CS, OUTPUT);
  //digitalWrite(FS_ETH_PIN_CS, LOW);
}

void ether_setup() {

  fs_eth_select();
  
  // Set SS pin (to co-exist with SD card on same SPI bus)
  Ethernet.init(FS_ETH_PIN_CS);

  #ifdef FS_ETH_DEBUG
    put_(F("# Eth begin..."));
  #endif
  
  //Ethernet.begin(mac);  // For DHCP
  //Ethernet.begin(mac, ip);
  Ethernet.begin(mac, ip, ip_dns, ip_gateway, ip_subnet);
  
  // Check for Ethernet hardware present
  if (Ethernet.hardwareStatus() == EthernetNoHardware) {
    #ifdef FS_ETH_DEBUG
      put(F("# Eth. error!"));
    #endif
  } else {
    #ifdef FS_ETH_DEBUG
      put_(F("# Eth IP:")); put(Ethernet.localIP());
    #endif
  }
  /*
  // Wait for cable
  while (Ethernet.linkStatus() == LinkOFF) {
    put("#Ethernet cable is not connected.");
    delay(500);
  }
  */
}


void ether_loop() {
  
}


#include "fs.h"

#define FS_ETH_MAX_PATH 32

// Forwards
void fs_eth_mount(const char *options);
file_DIR *fs_eth_opendir(const char *path);
int fs_eth_closedir(file_DIR * dir);
dirent *fs_eth_readdir(file_DIR *dir);
file_FILE *fs_eth_fopen(const char *path, const char *openMode);
int fs_eth_fclose(file_FILE *f);
byte fs_eth_feof(file_FILE *f);
int fs_eth_fgetc(file_FILE *f);
size_t fs_eth_fread(void *ptr, size_t size, size_t nmemb, file_FILE *f);
size_t fs_eth_fwrite(void *ptr, size_t size, size_t nmemb, file_FILE *f);


// Publish a FS struct
const FS fs_eth = {  // Keep in sync with fs.h:FS!
  fs_eth_mount,
  
  fs_eth_opendir,
  fs_eth_closedir,
  fs_eth_readdir,
  
  fs_eth_fopen,
  fs_eth_fclose,
  fs_eth_feof,
  //fs_eth_fgetc,
  fs_eth_fread,
  fs_eth_fwrite
};


// Implementation

char fs_eth_tmpName[FS_ETH_MAX_PATH];
file_DIR fs_eth_tmpDir;
dirent fs_eth_tmpDirent;
file_FILE fs_eth_tmpFile;

void fs_eth_mount(const char *options) {
  byte v;
  
  (void)options;
  
  ether_setup();
}

file_DIR *fs_eth_opendir(const char *path) {
  file_DIR * dir;  // file_DIR to be returned
  const char *pp;
  
  // Skip initial slash
  pp = path;
  if (*pp == FILE_PATH_DELIMITER) pp++;


  //@TODO: Implement! HTTP/FTP/TELNET/NFS/SMB/...
  
  return NULL;
  /*
  // Store handle
  fs_eth_tmpDirHandle = h;  //@FIXME: Using the ONE temp. dirHandle...
  
  dir = &fs_eth_tmpDir; //@FIXME: Using the ONE temp. dir...
  dir->fs = &fs_eth;
  dir->count = 0; //@TODO: Can be determined from SD
  dir->userData = (void *)&fs_eth_tmpDirHandle;
  
  dir->currentPos = 0;  // Rewind
  return dir;
  */
}

int fs_eth_closedir(file_DIR * dir) {
  /*
  File *dirHandle;
  
  //dirHandle = fs_eth_tmpDirHandle;
  dirHandle = (File *)dir->userData;
  dirHandle->close();
  */
  dir->count = 0;
  return 0;
}

dirent *fs_eth_readdir(file_DIR *dir) {
  return NULL;
  
  /*
  dirent *de;
  File *dirHandle;
  File fileHandle;
  
  //dirHandle = fs_eth_tmpDirHandle;
  dirHandle = (File *)dir->userData;
  
  fileHandle = dirHandle->openNextFile();
  //if (dir->currentPos >= dir->count) {
  if (!fileHandle) {
    // Done.
    return NULL;
  }
  
  //fileHandle.name()
  //fileHandle.isDirectory()
  //fileHandle.size()
  //fileHandle.available()
  
  // Create a dirent
  de = &fs_eth_tmpDirent;   //@FIXME: Using the ONE temp. dir.ent..
  de->pos = dir->currentPos;
  de->name = &fs_eth_tmpName[0];
  strcpy(&fs_eth_tmpName[0], fileHandle.name());
  
  dir->currentPos++;
  
  return de;
  */
}

file_FILE *fs_eth_fopen(const char *path, const char *openMode) {
  file_FILE *f; // file_FILE to be returned
  const char *pp;
  
  char fqdn[FS_ETH_MAX_FQDN];
  char upath[FS_ETH_MAX_PATH];
  int port;
  char *pp2;
  
  pp = path;
  if (*pp == FILE_PATH_DELIMITER) pp++; // Skip initial slash

  // Extract FQDN and remote path
  pp2 = &fqdn[0];
  while (*pp != 0) {
    if (*pp == '/') break;

    // To lower case
    if (( *pp >= 'A' ) && ( *pp <= 'Z' ))
      *pp2 = *pp - 'A' + 'a';
    else
      *pp2 = *pp;

    pp2++;
    pp++;
  }
  *pp2++ = 0; // Terminate FQDN

  // Extract path component
  pp2 = &upath[0];
  if (*pp == 0) {
    // No path component? Make it "/"
    *pp2++ = '/';
  } else {
    // Copy over the rest
    while (*pp != 0) {
      *pp2 = *pp;
      pp2++;
      pp++;
    }
  }
  *pp2++ = 0; // Terminate path

  port = 80;
  
  // Do the connection
  #ifdef FS_ETH_DEBUG
    put_(F("Connect to \"")); put_(fqdn); put_(F("\", path=\"")); put_(upath); put(F("\"..."));
  #endif

  fs_eth_select();
  
  if (fs_eth_client.connect(fqdn, port)) {
    // Send HTTP header(s)
    //client.println("GET /search?q=arduino HTTP/1.1");
    //client.println("Host: www.google.com");
    fs_eth_client.print(F("GET ")); fs_eth_client.print(upath); fs_eth_client.println(F(" HTTP/1.1"));
    fs_eth_client.print(F("Host: ")); fs_eth_client.println(fqdn);
    fs_eth_client.println(F("Connection: close"));
    fs_eth_client.println();
  } else {
    // Error
    #ifdef FS_ETH_DEBUG
      put(F("# Eth connect error."));
    #endif
    return NULL;
  }
  
  // Store handle
  f = &fs_eth_tmpFile;    //@FIXME: Using the ONE temp. file...
  f->name = &fs_eth_tmpName[0];
  strcpy(&fs_eth_tmpName[0], pp);

  f->fs = &fs_eth;
  f->userData = (void *)&fs_eth_client;
  f->size = 0;  //h.size(); // Not yet known
  
  f->mode = openMode;
  f->currentPos = 0;
  
  return f;
}

int fs_eth_fclose(file_FILE *f) {
  //File *h;
  
  //h = (File *)f->userData;
  //h->close();

  fs_eth_select();
  fs_eth_client.stop();
  
  return 0;
}

byte fs_eth_feof(file_FILE *f) {
  (void)f;
  return 1; //@TODO: Implement
}

int fs_eth_fgetc(file_FILE *f) {
  (void)f;
  return -1;  // EOF
}

size_t fs_eth_fread(void *ptr, size_t size, size_t nmemb, file_FILE *f) {
  //File *h;
  size_t l;
  
  size *= nmemb;
  
  //h = (File *)f->userData;
  //l = h->read(ptr, size);
  
  fs_eth_select();
  
  if (!fs_eth_client.connected()) {
    #ifdef FS_ETH_DEBUG
      put(F("#Eth: not connected"));
    #endif
    // Not connected!
    return 0;
  }

  // Wait until something is available (or disconnected)
  int len = 0;
  while((fs_eth_client.connected()) && (len == 0)) {
    len = fs_eth_client.available();
    delay(10);
  }
  #ifdef FS_ETH_DEBUG
    put_(F("#Eth: available=")); put(len);
  #endif
  
  if (len > 0) {
    if (len > size) len = size;
    fs_eth_client.read((uint8_t *)ptr, len);
    l = len;
    
  } else {
    // No data!
    
    return 0;
  }
  
  return l;
}

size_t fs_eth_fwrite(void *ptr, size_t size, size_t nmemb, file_FILE *f) {
  (void)ptr;
  (void)size;
  (void)nmemb;
  (void)f;
  
  //File h;
  //h = (File)f->userData;
  
  return 0;
}

#endif
